#*****************
#1. Election begets Election Election begets Election:----------
#A Multi-Model Approach to Predicting the Result of Swiss Initiatives and Referenda Using Historical Data 
#*****************
#Govarthanan Jeyatheeswaran, Valentin Louis Johner, Stefan Krummenacher, Noé Romeo Kuhn
#*****************
#Dear reader, please also follow the paper of the same title for further guidance.
#The code should run without errors, and any warnings may be ignored as the do not
# hinder the functioning of the code. 
#
#Enjoy. 



rm(list = ls())

library(tidyverse)
library(caret)
library(xgboost)     
library(rsample)     
library(vtreat)      
library(magrittr)
library(dplyr)
library(randomForest) 
library(ranger)       

#2. Dataset ------

Draw <- read.csv("Dataset1_Initiativen.csv", sep = ";")



D1 <- Draw %>%
  select(datum, titel_kurz_d, d1e1, d1e2, d1e3, rechtsform, anneepolitique,
         br.pos, nr.pos, nein.lager, ja.lager,bv.pos, nrja, nrnein, sr.pos, srja, srnein,
         dauer_bv, urheber, fr.dauer_samm, i.dauer_br, unter_g, p.fdp, p.sps, p.svp,
         p.mitte, p.evp, p.gps, p.glp, p.cvp, p.bdp, nr.wahl, w.fdp, w.sp, w.svp,
         w.mitte, w.evp, w.gps, w.glp, w.cvp, w.bdp, annahme, inserate.total,
         inserate.ja, inserate.nein, inserate.neutral, mediares.tot,
         mediaton.tot, poster_ja_mfg, poster_nein_mfg)


#3. Data cleaning----------------------------------------------------------------

D1[D1 == "."] <- NA 
D1[D1 == ""] <- NA
D1[D1 == 9999] <- NA #NA only for certain columns $

D1$datum %<>% as.character %<>% as.Date("%d.%m.%Y")



##Basic Features

Dbasic <- D1 %>%
  select(datum, srja, srnein, nrja, nrnein, nr.pos, br.pos, sr.pos, p.fdp, p.sps, p.svp,
         p.mitte, p.evp, p.gps, p.glp, p.cvp, p.bdp,w.fdp, w.sp, w.svp,
         w.mitte, w.evp, w.gps, w.glp, w.cvp, w.bdp, annahme)

#Filter rows after 1900 and delete future (incomplete) rows

Dbasic <- Dbasic %>%
  filter(datum >= "1900-05-20" & datum < "2021-11-28")

#change type to numeric

numeric_var = c("nr.pos", "srja", "srnein", "nrja","nrnein", "br.pos", "sr.pos", "p.fdp", "p.sps", "p.svp", 
                "p.mitte", "p.evp", "p.gps", "p.glp", "p.cvp", "p.bdp", "w.fdp",
                "w.sp", "w.svp", "w.mitte", "w.evp", "w.gps", "w.glp", "w.cvp",
                "w.bdp", "annahme")

for (i in numeric_var) {
  
  Dbasic[[i]] = as.numeric(Dbasic[[i]])
  
}

str(Dbasic) #check type 

Dbasic$srnein <- Dbasic$srnein * -1
Dbasic$nrnein <- Dbasic$nrnein * -1 

#combine data for cvp, bdp and mitte

Dbasic <- Dbasic %>%
  mutate(p.cvpmitte = ifelse(is.na(p.mitte), p.cvp, p.mitte)) %>%
  mutate(w.cvpmitte = ifelse(is.na(w.mitte), w.cvp, w.mitte)) %>%
  select(-p.cvp, -p.mitte, -w.cvp, -w.mitte)

Dbasic <- Dbasic %>%
  mutate(w.cvpmitte = ifelse(is.na(w.cvpmitte), 0, w.cvpmitte)) %>%
  mutate(w.bdp = ifelse(is.na(w.bdp), 0, w.bdp)) %>% #NA zu 0 machen damit Addition nicht = NA
  mutate(w.cvpbdpmitte = w.cvpmitte + w.bdp) %>%
  mutate(w.cvpbdpmitte = ifelse(w.cvpbdpmitte == 0, NA, w.cvpbdpmitte)) %>% # 0 wieder zu NA machen
  select(-w.cvpmitte, -w.bdp)

Dbasic <- Dbasic %>%
  mutate(p.bdp = ifelse(is.na(p.bdp), p.cvpmitte, p.bdp)) # NA bei BDP mit Mitte auffüllen

Dbasic <- Dbasic %>%
  mutate(p.cvpbdpmitte = ifelse(p.bdp == p.cvpmitte, p.bdp, p.cvpmitte)) %>% # Da wo keine Übereinstimmung in Parteiparole, die der CVP wählen da diese grösser sind, somit hat man eine Mitte von Anfang an
  select(-p.cvpmitte, -p.bdp)

#table(is.na(Dbasic)) check if we accidentally created NAs 

table(is.na(Dbasic))

#check type

str(Dbasic) 

#for all p.party change values 4, 5, 66 to 3 (neutral) (just cleaner, not necessary)

Dbasic$p.cvpbdpmitte[Dbasic$p.cvpbdpmitte == "66" | Dbasic$p.cvpbdpmitte == "5" | Dbasic$p.cvpbdpmitte == "4"] <- 3
Dbasic$p.evp[Dbasic$p.evp == "5" | Dbasic$p.evp == "4"] <- 3
Dbasic$p.gps[Dbasic$p.gps == "5" | Dbasic$p.gps == "4"] <- 3
Dbasic$p.glp[Dbasic$p.glp == "5"] <- 3
Dbasic$p.fdp[Dbasic$p.fdp == "5" | Dbasic$p.fdp == "66"] <- 3
Dbasic$p.svp[Dbasic$p.svp == "5" | Dbasic$p.svp == "66"] <- 3
Dbasic$p.sps[Dbasic$p.sps == "66" | Dbasic$p.sps == "5" | Dbasic$p.sps == "4"] <- 3

#controlled with a table, thus not always 4, 5 and 66 needed to replace


# Wähleranteil anpassen, dass je nach Parole die Wähleranteile pos (Ja) oder neg (Nein) sind
Dbasic$w.fdp <- ifelse(Dbasic$p.fdp == 1, Dbasic$w.fdp, (-1) * Dbasic$w.fdp)
Dbasic$w.sp <- ifelse(Dbasic$p.sps == 1, Dbasic$w.sp, (-1) * Dbasic$w.sp)
Dbasic$w.svp <- ifelse(Dbasic$p.svp == 1, Dbasic$w.svp, (-1) * Dbasic$w.svp)
Dbasic$w.cvpbdpmitte <- ifelse(Dbasic$p.cvpbdpmitte == 1, Dbasic$w.cvpbdpmitte, (-1) * Dbasic$w.cvpbdpmitte)
Dbasic$w.evp <- ifelse(Dbasic$p.evp == 1, Dbasic$w.evp, (-1) * Dbasic$w.evp)
Dbasic$w.gps <- ifelse(Dbasic$p.gps == 1, Dbasic$w.gps, (-1) * Dbasic$w.gps)
Dbasic$w.glp <- ifelse(Dbasic$p.glp == 1, Dbasic$w.glp, (-1) * Dbasic$w.glp)

# Daten mit Parolen ohne Ja oder Nein, Wähleranteil = 0 setzen
Dbasic$w.fdp <- ifelse(Dbasic$p.fdp == 1 | Dbasic$p.fdp == 2, Dbasic$w.fdp, 0)
Dbasic$w.sp <- ifelse(Dbasic$p.sps == 1 | Dbasic$p.sps == 2, Dbasic$w.sp, 0)
Dbasic$w.svp <- ifelse(Dbasic$p.svp == 1 | Dbasic$p.svp == 2, Dbasic$w.svp, 0)
Dbasic$w.cvpbdpmitte <- ifelse(Dbasic$p.cvpbdpmitte == 1 | Dbasic$p.cvpbdpmitte == 2, Dbasic$w.cvpbdpmitte, 0)
Dbasic$w.evp <- ifelse(Dbasic$p.evp == 1 | Dbasic$p.evp == 2, Dbasic$w.evp, 0)
Dbasic$w.gps <- ifelse(Dbasic$p.gps == 1 | Dbasic$p.gps == 2, Dbasic$w.gps, 0)
Dbasic$w.glp <- ifelse(Dbasic$p.glp == 1 | Dbasic$p.glp == 2, Dbasic$w.glp, 0)

# Parolen entfernen, weil Information jetzt in w.PARTEI enthalten
Dbasic <- Dbasic %>%
  select(-p.fdp, -p.sps, -p.svp, -p.cvpbdpmitte, -p.evp, -p.gps, -p.glp)

Dbasic <- Dbasic %>%
  filter(nr.pos %in% c(1,2)) %>%
  filter(sr.pos %in% c(1,2)) %>%
  filter(br.pos %in% c(1,2))

Dbasic$nr.pos <- ifelse(Dbasic$nr.pos == 2, 0, 1)
Dbasic$br.pos <- ifelse(Dbasic$br.pos == 2, 0, 1)
Dbasic$sr.pos <- ifelse(Dbasic$sr.pos == 2, 0, 1)

##Dbasic is clean!

#Standardize Dbasic:

features = c("srja", "srnein", "nrja","nrnein", "nr.pos", "br.pos", "sr.pos", "w.fdp",
             "w.sp", "w.svp", "w.evp", "w.gps", "w.glp", "w.cvpbdpmitte")

#replace NAs with 0

features_standardize = c("srja", "srnein", "nrja","nrnein", "w.fdp","w.sp", "w.svp",
                         "w.evp", "w.gps", "w.glp", "w.cvpbdpmitte")

Dbasic[is.na(Dbasic)] <- 0

Dbasic_raw <- Dbasic

for (i in features_standardize){
  Dbasic[[i]] = (Dbasic[[i]] - mean(Dbasic[[i]])) / sd(Dbasic[[i]])
}

#3 different sized Dbasic for accuracy 

#Dbasic1 

Dbasic1 <- Dbasic %>%
  filter(datum >= "1920-03-21") #Post WW1

Dbasic2 <- Dbasic %>%
  filter(datum >= "1981-06-14") #Post 70s oil crisis stagflation turmoil 

Dbasic3 <- Dbasic %>%
  filter(datum >= "2002-09-22") #Post 9/11 modern


Dbasic1 <- Dbasic1 %>%
  select(-datum)

Dbasic2 <- Dbasic2 %>%
  select(-datum)

Dbasic3 <- Dbasic3 %>%
  select(-datum)

#Checking how common 1 (passing) is in the target variable

sum(Dbasic1$annahme == 1)/length(Dbasic1$annahme)
sum(Dbasic2$annahme == 1)/length(Dbasic2$annahme)
sum(Dbasic3$annahme == 1)/length(Dbasic3$annahme)

#4. Dbasics are clean!!!----

Dlr <- Dbasic2 #This dataset will be used for the whole rest of the code

#5.1.1 Logistic Regression---------------------------------------------

#Variables:


c <- 0.5

#Generalized model

modeldumb <- glm(annahme ~ . , family = "binomial", data = Dlr)

?glm

Dlr <- Dlr %>%
  mutate(Prediction = predict(modeldumb, type = "response")) %>%
  mutate(Prediction2 = ifelse(Prediction >= c, 1, 0))

mean(Dlr$Prediction2 == Dlr$annahme)

#LETS GOOO 80% Accuracy

#4. Three Methods to check for overfitting-------

Dlr <- Dlr %>%
  select(-Prediction, -Prediction2)

# n folds

k = 5 #define the ratio of train to test

shufDmodeldumb <- Dlr[sample(nrow(Dlr)), ]

folds <- cut(seq(1,nrow(shufDmodeldumb)),breaks=k,labels=FALSE)

#Perform 5 fold cross validation
for(i in 1:k){
  #Segement your data by fold using the which() function 
  testIndexes <- which(folds==i,arr.ind=TRUE)
  testData <- shufDmodeldumb[testIndexes, ]
  trainData <- shufDmodeldumb[-testIndexes, ]
  
  
}

#checking for leakage...

testcrossval = 0

for (j in nrow(testData)) {
  
  for (i in nrow(trainData)) {
    
    if(sum(testData[j,] == trainData[i,]) == 19) {
      testcrossval <- testcrossval + 1
    }
    
  }
}

ifelse(testcrossval > 0, print("gosh darn it, there is leakage"), print("heck yeah no leakage"))

#check 

modeldumb <- glm(annahme ~ . , family = "binomial", data = trainData)

testData <- testData %>%
  mutate(Testscore = predict(modeldumb, type = "response", newdata = testData)) %>%
  mutate(Testprediction = ifelse(Testscore >= c, 1, 0))

mean(testData$annahme == testData$Testprediction) #accuracy

testData <- testData %>%
  select(-Testscore, -Testprediction)

#*************************
#A (manual) approach at cross validation 
#Im certain one could loop this nicely. 

k <- 5
crossValAcc <- 0 

k1 <- shufDmodeldumb[1:(round(nrow(shufDmodeldumb)/k)),]

for(i in 2:k) {                    
  assign(paste0("k", i),shufDmodeldumb[(((round(nrow(shufDmodeldumb)/k))*(i-1))+1):((round(nrow(shufDmodeldumb)/k))*i),])
}

#I checked using the above algorithm if any rows of the k's are equal. There is no leakage 

#Here you will have to add manually if there are more folds

shufDmodeldumb5 <- rbind(k1, k2, k3, k4) #k5
shufDmodeldumb4 <- rbind(k1, k2, k3, k5) #k4
shufDmodeldumb3 <- rbind(k1, k2, k4, k5) #k3
shufDmodeldumb2 <- rbind(k1, k3, k4, k5) #k2
shufDmodeldumb1 <- rbind(k2, k3, k4, k5) #k1

#input different test- and respective training data set
#Loopen durch vector 
CVtrain <- shufDmodeldumb1
CVtest <- k1

modeldumbcv <- glm(annahme ~ . , family = "binomial", data = CVtrain)

CVtest <- CVtest %>%
  mutate(Prediction = predict(modeldumb, type = "response", newdata = CVtest)) %>%
  mutate(Prediction2 = ifelse(Prediction >= c, 1, 0))

crossValAcc  <- crossValAcc + mean(CVtest$Prediction2 == CVtest$annahme)

crossValAcc / 5 #This is the cross validated accuracy 

#cleaning environment
rm(k1, k2, k3, k4, k5, modeldumbcv, shufDmodeldumb1, shufDmodeldumb2,
   shufDmodeldumb3, shufDmodeldumb4, shufDmodeldumb5, testcrossval, CVtest)

#******************************
#Cross Validation Classic Caret

#folds :

f <- 5

#change the type of the target variable to factor

Dlr$annahme = as.factor(Dlr$annahme)

Dlr_ctrl <- trainControl(method = "cv", number = f)

modeldumb_caret <- train(annahme ~ .,
                         data = Dlr,                        
                         trControl = Dlr_ctrl,
                         method = "glm",                  
                         family = "binomial",
                         na.action = na.pass)

modeldumb_caret

modeldumb_caret$finalModel

modeldumb_caret$results

rm(shufDmodeldumb)

# 4.1.1 Logistic regression again with trainData--------

#Variables:

Dlr_final <- trainData
c <- 0.5

#Generalized model

modeldumb_final <- glm(annahme ~ . , family = "binomial", data = Dlr_final)

Dlr_final <- Dlr_final %>%
  mutate(score_lr = predict(modeldumb_final, type = "response")) %>%
  mutate(prediction_lr = ifelse(score_lr >= c, 1, 0))

mean(Dlr_final$prediction_lr == Dlr_final$annahme)

#Apply it on testData:

score_lr_test = predict(modeldumb_final, newdata = testData, type = "response")

prediction_lr_test = ifelse(score_lr_test >= c, 1, 0)

mean(prediction_lr_test == testData$annahme)



# 4.1.2 Home-made ROC curve----------

#Initialisation

ROCn.Values <- 1000

ROC <- as_tibble(matrix(nrow = ROCn.Values, ncol = 2 ))

colnames(ROC) <- c("FPR", "TPR")

ROC$FPR <- as.numeric(ROC$FPR)
ROC$TPR <- as.numeric(ROC$TPR)

#ROC Curve mapping

modeldumb <- glm(annahme ~ . , family = "binomial", data = Dlr)


for (c in seq(from = 1/ROCn.Values, to = 1, by = 1/ROCn.Values)) {
  Dlr <- Dlr %>%
    mutate(Prediction = predict(modeldumb, type = "response" )) %>%
    mutate(Prediction2 = ifelse(Prediction >= c, 1, 0))
  
  labels <- Dlr$annahme
  scores  <- Dlr$Prediction2
  
  
  FP <- sum(ifelse(scores ==1 & labels == 0, 1, 0) )
  TP <- sum(ifelse(scores == 1 & labels == 1, 1, 0))
  TN <- sum(ifelse(scores == 0 & labels == 0, 1, 0))
  FN <- sum(ifelse(scores ==0 & labels == 1, 1, 0))
  
  i <- c*ROCn.Values
  i <- round(i)
  
  ROC[i,1] <-  FP/ (FP + TN)   #FPR
  ROC[i,2] <- TP/ (TP + FN)   #TPR
  
  Dlr <- Dlr %>%
    select( -Prediction, -Prediction2)
  
}

ggplot(ROC, aes(x = FPR, y = TPR)) +
  geom_line()

# Optimizing for c using pythagoras 

ROC <- ROC %>%
  mutate(c = seq(from = 1/ROCn.Values, to = 1, by = 1/ROCn.Values)) %>%
   mutate(Hypotenuse = 0) 

   
   for (i in 1:length(ROC$c)) {
      
         ROC[i,4] <- sqrt((ROC[i,1]^2)+(1-ROC[i,2])^2)
         }

#Sort by hypotenuse to see the smallest hypotenuse
   
 
#The hypotenuse tends towards 0.5. 
#As we are only interested in accuracy, the best classifier is obviously 0.5

c <- 0.5
   

   
# 4.2 Stochastic gradient descent--------------------------------------------------
#Homemade 
Dsgd <- trainData

eta = 0.01  #trial and error good accuracy with 0.01 -> decreasing eta etc. possible (see loop)


wList = matrix(NA, ncol=length(features)+1, nrow = nrow(Dsgd))

w = rep(0, length(features)+1)



for (i in 1:nrow(Dsgd)){
  
  
  x_i = as.numeric(Dsgd[features][i, ])  
  
  y_i = Dsgd$annahme[i]    
  
  score_i = w[1] + w[2]*x_i[1] + w[3]*x_i[2] + w[4]*x_i[3] + w[5]*x_i[4] + w[6]*x_i[5] +
    w[7]*x_i[6] + w[8]*x_i[7] + w[9]*x_i[8] + w[10]*x_i[9] + w[11]*x_i[10] +
    w[12]*x_i[11] + w[13]*x_i[12] + w[14]*x_i[13] + w[15]*x_i[14]
  
  pred_i = ifelse(score_i>=c, 1, 0)  
  
  Dsgd$score = w[1] + w[2]*Dsgd[[features[1]]] + w[3]*Dsgd[[features[2]]] +
    w[4]*Dsgd[[features[3]]] + w[5]*Dsgd[[features[4]]] +
    w[6]*Dsgd[[features[5]]] + w[7]*Dsgd[[features[6]]] +
    w[8]*Dsgd[[features[7]]] + w[9]*Dsgd[[features[8]]] +
    w[10]*Dsgd[[features[9]]] + w[11]*Dsgd[[features[10]]] +
    w[12]*Dsgd[[features[11]]] + w[13]*Dsgd[[features[12]]] +
    w[14]*Dsgd[[features[13]]] + w[15]*Dsgd[[features[14]]] 
  
  Dsgd$prediction = ifelse(Dsgd$score >=c, 1, 0)
  
  Dsgd$error  = Dsgd$annahme - Dsgd$prediction
  
  wList[i, ] = w
  
  w[-1] = w[-1] + eta*(y_i - score_i) * x_i   
  
  w[1] = w[1] + eta*(y_i - score_i)          
  
  #eta = eta*0.99 tried to decrease eta every round -> doesn't get better
}

wFinal = wList[nrow(Dsgd), ]

print((sum(Dsgd$error == 0))/length(Dsgd$error)) #accuracy

#Cross Validation SGD

k <- 5
crossValAcc <- 0 
shufDmodeldumb <- Dbasic2[sample(nrow(Dsgd)), ]

k1 <- shufDmodeldumb[1:(round(nrow(shufDmodeldumb)/k)),]

for(i in 2:k) {                    
  assign(paste0("k", i),shufDmodeldumb[(((round(nrow(shufDmodeldumb)/k))*(i-1))+1):((round(nrow(shufDmodeldumb)/k))*i),])
}

#I checked using the above algorithm if any rows of the k's are equal. There is no leakage 

#Here you will have to add manually if there are more folds

shufDmodeldumb5 <- rbind(k1, k2, k3, k4) #k5
shufDmodeldumb4 <- rbind(k1, k2, k3, k5) #k4
shufDmodeldumb3 <- rbind(k1, k2, k4, k5) #k3
shufDmodeldumb2 <- rbind(k1, k3, k4, k5) #k2
shufDmodeldumb1 <- rbind(k2, k3, k4, k5) #k1

#input different test- and respective training data set
#Loopen durch vector 
CVtrain <- shufDmodeldumb5
CVtest <- k5


#Train and test

wList = matrix(NA, ncol=length(features)+1, nrow = nrow(CVtrain))

w = rep(0, length(features)+1)



for (i in 1:nrow(CVtrain)){
  
  
  x_i = as.numeric(CVtrain[features][i, ])  
  
  y_i = CVtrain$annahme[i] 
  
  score_i = w[1] + w[2]*x_i[1] + w[3]*x_i[2] + w[4]*x_i[3] + w[5]*x_i[4] + w[6]*x_i[5] +
    w[7]*x_i[6] + w[8]*x_i[7] + w[9]*x_i[8] + w[10]*x_i[9] + w[11]*x_i[10] +
    w[12]*x_i[11] + w[13]*x_i[12] + w[14]*x_i[13] + w[15]*x_i[14]
  
  pred_i = ifelse(score_i>=c, 1, 0)  
  
  CVtrain$score = w[1] + w[2]*CVtrain[[features[1]]] + w[3]*CVtrain[[features[2]]] +
    w[4]*CVtrain[[features[3]]] + w[5]*CVtrain[[features[4]]] +
    w[6]*CVtrain[[features[5]]] + w[7]*CVtrain[[features[6]]] +
    w[8]*CVtrain[[features[7]]] + w[9]*CVtrain[[features[8]]] +
    w[10]*CVtrain[[features[9]]] + w[11]*CVtrain[[features[10]]] +
    w[12]*CVtrain[[features[11]]] + w[13]*CVtrain[[features[12]]] +
    w[14]*CVtrain[[features[13]]] + w[15]*CVtrain[[features[14]]] 
  
  CVtrain$prediction = ifelse(CVtrain$score >=c, 1, 0)
  
  CVtrain$error  = CVtrain$annahme - CVtrain$prediction
  
  wList[i, ] = w
  
  w[-1] = w[-1] + eta*(y_i - score_i) * x_i   
  
  w[1] = w[1] + eta*(y_i - score_i)          
  
  #eta = eta*0.99 tried to decrease eta every round -> doesn't get better
}

wFinal = wList[nrow(CVtrain), ]


#Apply on test

#Create an empty list:

test_sgd_CV <- rep(NA, nrow(CVtest))

#Fill with starting value (first weight)

for (i in 1:nrow(CVtest)) {
  test_sgd_CV[i] <- as.numeric(wFinal[1])
}

#apply weights to features for every row

for (i in 1:length(features)) {
  for(j in 1:nrow(CVtest)) {
    test_sgd_CV[j] = test_sgd_CV[j] + wFinal[i+1] * CVtest[j, i]
  }
}

#Transform list to a tibble

test_sgd_CV <- tibble(as.numeric(test_sgd_CV))

colnames(test_sgd_CV) <- "score"

#Add prediction from score

test_sgd_CV$prediction <- ifelse(test_sgd_CV$score >= 0.5, 1, 0)

#Add annahme to test prediction

test_sgd_CV <- cbind(test_sgd_CV, CVtest$annahme)

test_sgd_CV <- rename(test_sgd_CV, annahme = "CVtest$annahme")

#Calculate error and accuracy

test_sgd_CV$error  = test_sgd_CV$annahme - test_sgd_CV$prediction

crossValAcc <- crossValAcc + ((sum(test_sgd_CV$error == 0))/length(test_sgd_CV$error))

crossValAcc / 5 #This is the cross validated accuracy 


##Test it on Test Dataset:

#Create an empty list:

test_sgd <- rep(NA, nrow(testData))

#Fill with starting value (first weight)

for (i in 1:nrow(testData)) {
  test_sgd[i] <- as.numeric(wFinal[1])
}

#apply weights to features for every row

for (i in 1:length(features)) {
  for(j in 1:nrow(testData)) {
    test_sgd[j] = test_sgd[j] + wFinal[i+1] * testData[j, i]
  }
}

#Transform list to a tibble

test_sgd <- tibble(as.numeric(test_sgd))

colnames(test_sgd) <- "score"

#Add prediction from score

test_sgd$prediction <- ifelse(test_sgd$score >= 0.5, 1, 0)

#Add annahme to test prediction

test_sgd <- cbind(test_sgd, testData$annahme)

test_sgd <- rename(test_sgd, annahme = "testData$annahme")

#Calculate error and accuracy

test_sgd$error  = test_sgd$annahme - test_sgd$prediction

((sum(test_sgd$error == 0))/length(test_sgd$error))





#***************
#4.3 Neural Network--------- 
#***************

Dnn <- trainData


# Parameters NN 

nZ = 190  # Number of nodes in the hidden layer: Optimized by trial and error 
maxEpochs = 100  # How many times do we go through the data for training: Ibid
eta = 0.5  # learning rate: Ibid
initRange = 10  # Range for initialization of weights: Ibid
c = 0.5 #classification parameter

# Model training NN
#Initialization

nX <- length(features)


# Initialize weight matrices

# w1
w1  = matrix(runif(nX * nZ, min = - initRange, max = initRange),
             nrow = nX)
rownames(w1) = paste0("X", 1:nX)
colnames(w1) = paste0("Z", 1:nZ)


# w2
w2  = matrix(runif(nZ, min = - initRange, max = initRange),
             ncol = 1)
rownames(w2) = paste0("Z", 1:nZ)
colnames(w2) = "T"


# the sigmoid...

sigmoidFun = function(x){
  1/(1+exp(-x))
}


#Prediction function 

evalPredictionsFun = function(Dnn, w1, w2){
  
  X = as.matrix(Dnn[, 1:nX])   # This has dimension nCases x nX
  
  S = X %*% w1                # w1 has dimension nCases x nZ
  
  Z = sigmoidFun(S)           # Same dimensions as S
  
  
  T = Z %*% w2                # w2 has dimension nZ x 1 (for single output node)
  
  prob = sigmoidFun(T)        # Predicted probabilities for output layer
  
  
  #loss function (negative log likelihood in this case)
  loss =  - sum(
    Dnn$annahme * log(prob) + (1-Dnn$annahme) * log(1-prob) )
  
  pred = ifelse(prob >= c, 1, 0) # Convert into 0/1 prediction
  
  misClas = mean(pred != Dnn$annahme)
  
  out = list(loss = loss, misClas = misClas, prob = prob, pred = pred)
  
  return(out)
  
}



# Initialization of counters and lists

lossList = rep(NA, maxEpochs + 1)  # Used for plotting of learning progress
misClasList = lossList             # For the same purpose 

epochCounter = 0  #(we use stochastic gradient descent)


# Calculate and insert initial loss and misClas values

initEval = evalPredictionsFun(Dnn, w1, w2)

loss = initEval$loss
misClas = initEval$misClas

# Insert first entry in our learning lists
lossList[epochCounter + 1] = loss
misClasList[epochCounter + 1] = misClas


#Learning 

while (epochCounter< maxEpochs){
  
  # update epoch counter
  epochCounter = epochCounter + 1
  
  # Randomly reshuffle data, we do not want
  # to go through the data every time in the same order
  resh = sample(1:nrow(Dnn))
  Dnn = Dnn[resh,]
  
  
  
  
  for (i in 1:nrow(Dnn)){ 
    
    #i = 1
    
    # extract feature and target values for case i
    # We need Xi as matrix for matrix multiplication below
    Xi = as.matrix(Dnn[i, c(1,2,3,4,5,6,7,8,9,10,11,12,13,15)])
    Yi = Dnn$annahme[i]
    
    
    
    # Forward pass
    # ************
    
    # Given weights (from initialization or from the
    # last learning round), we calculate our predictions
    # using xi, w1, w2
    
    # Calculate the scores that go into the calculation of 
    # the hidden nodes
    Si = Xi %*% w1   
    
    
    # A piece of error management
    if (sum(is.na(Si)> 0)){
      stop(paste0("Si is NA for epoch ", epochCounter, " and i = ", i))
    }
    
    # The hidden nodes
    Zi = sigmoidFun(Si)
    
    rownames(Zi) = "T"
    
    # The score that goes into the calculation of the final output
    Ti = Zi %*% w2
    
    # The final output in probability form
    prob_i = sigmoidFun(Ti)
    
    
    # Backward pass / updating
    
    error_i = as.numeric(Yi - prob_i)
    # Use as.numeric for obtaining a vector rather than a tibble
    
    # The gradient with respect to w2
    gradient2_i = -error_i * t(Zi)
    
    # The gradient with respect to w1
    gradient1_i = -error_i  *   t(Xi) %*% 
      
      (t(w2) * Zi * (1-Zi))  
    
    
    
    # Updating: Go eta units in the direction of the negative of the gradient
    
    w1 = w1 - eta * gradient1_i
    w2 = w2 - eta * gradient2_i
    
    
    # A piece of error management.
    
    if (sum(is.infinite(gradient1_i)>0)){
      these = which(is.infinite(gradient1_i))
      w1[these] = 0
    }
    
  }  # end of loop through observations
  
  # Evaluate learning progress
  
  
  evalPredictions = evalPredictionsFun(Dnn, w1, w2)
  
  loss = evalPredictions$loss
  misClas = evalPredictions$misClas
  
  lossList[epochCounter + 1] = loss
  misClasList[epochCounter + 1] = misClas
  
  print(paste0("Done with epoch ", epochCounter))
  
  eta <- eta * 0.95
  
}

######Output NN

trainedWeights = list(w1 = w1, w2 = w2)

trainedModel = evalPredictionsFun(Dnn, trainedWeights$w1, trainedWeights$w2)

Dnn$prob = trainedModel$prob
Dnn$pred = trainedModel$pred

mean(Dnn$annahme == Dnn$pred)



NN <- function(testData, w1, w2){
  
  X = as.matrix(testData[, 1:nX])   
  
  S = X %*% w1               
  
  Z = sigmoidFun(S)           
  
  T = Z %*% w2                
  
  prob = sigmoidFun(T)        
  
  out = list(prob = prob)
  
  return(out)
  
}



NNscore <-NN(testData,w1,w2)

NNscore <- as_tibble(NNscore)
NNprediction <- ifelse(NNscore >= c, 1, 0)

colnames(NNprediction) <- "PredictionNN"
colnames(NNscore) <- "ScoreNN"


#*****************************
# 4.4 Gradient Boosting Machines----------------------------------------------------
#*****************************

##preparing matrix

# feature names
features <- setdiff(names(trainData), "annahme")

# variable treatment plan 
treatplan <- vtreat::designTreatmentsZ(trainData, features, verbose = FALSE)
cbind(treatplan$scoreFrame[,c("origName", "varName", "code")])
unique(treatplan$scoreFrame$code)

# Collect variables in vector
new_vars <- treatplan %>%
  magrittr::use_series(scoreFrame) %>%        
  dplyr::filter(code %in% c("clean")) %>% 
  magrittr::use_series(varName)     

# Prepare training data 
features_train <- vtreat::prepare(treatplan, trainData, varRestriction = new_vars) %>% as.matrix()
response_train <- trainData$annahme

# Prepare test data 
features_test <- vtreat::prepare(treatplan, testData, varRestriction = new_vars) %>% as.matrix()
response_test <- testData$annahme

# xgb.Dmatrix
dtrain <- xgb.DMatrix(data = features_train, label = response_train) 
dtest <- xgb.DMatrix(data = features_test, label = response_test)



# Training boosting models 


# parameter list

params <- list(
  booster = "gbtree",
  objective = "binary:logistic",
  eta = 0.01,
  max_depth = 2,
  min_child_weight = 4,
  gamma = 0,
  subsample = 0.15,
  colsample_bytree = 0.3,
  nfold = 0.2
)

# boosting with CV (to find out good parameters)
#takes really long, thus with #

#xgbcv <- xgb.cv( params = params, 
#                 data = dtrain,
#                 nrounds = 200, 
#                 nfold = 0.2, 
#                 showsd = T, 
#                 stratified = T, 
#                 print_every_n = 10, 
#                 early_stopping_rounds = 20,
#                 metrics = "error",
#                 maximize = F,
#                 prediction = T)


#training

watchlist <- list(train=dtrain, test=dtest)

xgb1 <- xgb.train(
  params = params, 
  data = dtrain,
  watchlist = watchlist,
  nrounds = 100,
  print_every_n = 1, 
  early_stopping_rounds = 20, 
  eval_metric = "error")

#prediction

xgbscore <- predict(xgb1, features_test)
xgbpred <- ifelse (xgbscore >= 0.5,1,0)
mean(testData$annahme == xgbpred)



# Variable importance ----

# importance matrix
importance_matrix <- xgb.importance(model = xgb1)

class(importance_matrix)

which.max(importance_matrix$Gain)

xgb.plot.importance(importance_matrix, top_n = 10, measure = "Gain")



#***************
### 4.5 Random Forest --------------------------------------
#***************



# Parameter RF
# ***********************
Drf = trainData
Drf$annahme = as.factor(Drf$annahme)


# Default RF
# ***********************
modelrf <- randomForest(
  formula = annahme ~ .,  
  data    = Drf
)

modelrf$ntree #default model makes 500 trees

# plot the error rates
plot(modelrf, col = c("red", "blue", "green"))
legend(400, 0.4, legend = c("OOB", "0", "1"), col = c("red", "blue", "green"), fill = c("red", "blue", "green"))

rf_error = as_tibble(modelrf[["err.rate"]])
rf_error$OOB
which.min(rf_error$OOB) # position of min. OOB-error-rate
rf_error$OOB[which.min(rf_error$OOB)] # min. OOB-error-rate

modelrf[["importance"]] # importance matrix

mean(modelrf$predicted == modelrf$y)# Accuracy 80,5%

mean(predict(modelrf, newdata = testData) == testData$annahme) # 50% on test data



# Validation set approach RF
# ***********************
Drf_valid_split <- initial_split(Drf, .8)

# training data
Drf_train_v <- training(Drf_valid_split)

# validation/test data
Drf_test_v <- testing(Drf_valid_split)

x_test <- Drf_test_v[setdiff(names(Drf_test_v), "annahme")]
y_test <- Drf_test_v$annahme
y_test

# model for getting both validation set errors
# and OOB errors, so we can compare.
modelrf_oob_v <- randomForest(
  formula = annahme ~ .,
  data    = Drf_train_v,
  xtest   = x_test,
  ytest   = y_test,
  keep.forest = TRUE
  
)


# Check for same length
length(modelrf_oob_v$test$predicted)
length(y_test)

# Accuracy
mean(modelrf_oob_v$predicted == Drf_train_v$annahme) # OOB
mean(modelrf_oob_v$test$predicted == y_test) # validation

# asign error rates for plotting
oob_error_rate <- as_tibble(modelrf_oob_v$err.rate)
validation_error_rate <- as_tibble(modelrf_oob_v$test$err.rate)

# plot the error rates
tibble(
  "Out of Bag Error-Rate" = oob_error_rate$OOB,
  "Test error-rate" = validation_error_rate$Test,
  ntrees = 1:modelrf_oob_v$ntree)   %>%
  
  pivot_longer(cols = -ntrees, 
               names_to = "Percent", values_to = "Error_Rate") %>% 
  
  ggplot(aes(ntrees, Error_Rate, color = Percent)) +
  geom_line() +
  xlab("Number of trees")

# Tunnig RF
# ***********************

# tuning over mtry,

# we use oob errors rates for determining the "best" tree.

# names of features
features_rf <- setdiff(names(Drf), "annahme")

modelrf_t <- tuneRF(
  x          = Drf[features],
  y          = Drf$annahme,
  ntreeTry   = 500,
  mtryStart  = 2,
  stepFactor = 1.5,       
  improve    = 0.01,      
  trace      = FALSE,      
  
)

# The output of this is a graph and 2 to 4 numbers! I get 3 as the optimal mtry value.
modelrf_tuned <- randomForest(
  formula = annahme ~ .,  
  data    = Drf,
  mtry = 3
)

mean(predict(modelrf_tuned, newdata = testData)==testData$annahme)


# Hyperparameter grid search RF
# ***********************

Drf_col = ncol(Drf) -1


hyper_grid <- expand.grid(
  mtry       = seq(2, Drf_col, by = 2),
  node_size  = seq(3, length(features), by = 2),
  sample_size = c(.55, .632, .70, .80),
  OOB_ERROR_RATE   = 0, 
  ACC = 0
)


nrow(hyper_grid)

for(i in 1:nrow(hyper_grid)) {
  
  
  model <- ranger(
    formula         = annahme ~ ., 
    data            = Drf, 
    num.trees       = 500,
    mtry            = hyper_grid$mtry[i],
    min.node.size   = hyper_grid$node_size[i],
    sample.fraction = hyper_grid$sample_size[i], 
    oob.error = TRUE
  )
  
  
  hyper_grid$ACC[i] <- mean(model$predictions == Drf$annahme)
  hyper_grid$OOB_ERROR_RATE[i] <- (model$prediction.error)
}

hyper_grid %>% 
  dplyr::arrange(OOB_ERROR_RATE) %>%
  head(10)


best_rf_param <- hyper_grid %>% 
  dplyr::arrange(OOB_ERROR_RATE) %>%
  head(1)
# The output of the best line is:
#-> mtry 12, node 5, sample 0.55


# Repeating model 100 times to get better expectation for oob error-rate and its SD 
OOB_E_R <- vector(mode = "numeric", length = 100)

for(i in seq_along(OOB_E_R)) {
  
  optimal_ranger <- ranger(
    formula         = annahme ~ ., 
    data            = Drf, 
    num.trees       = 500,
    mtry            = best_rf_param$mtry,
    min.node.size   = best_rf_param$node_size,
    sample.fraction = best_rf_param$sample_size,
    importance      = 'impurity' # Gini index
  )
  
  OOB_E_R[i] <- optimal_ranger$prediction.error
  
  print(i)
}

hist(OOB_E_R, breaks = 20)



class(optimal_ranger$variable.importance)

names(optimal_ranger$variable.importance)

tibble(x = optimal_ranger$variable.importance,
       labels = names(optimal_ranger$variable.importance)) %>%
  dplyr::arrange(desc(x)) %>%
  ggplot(aes(reorder(labels, x), x)) +
  geom_col() +
  coord_flip() +
  ggtitle("Importance of variables")



optimal_ranger_prob <- ranger(
  formula         = annahme ~ ., 
  data            = Drf, 
  num.trees       = 500,
  mtry            = best_rf_param$mtry,
  min.node.size   = best_rf_param$node_size,
  sample.fraction = best_rf_param$sample_size,
  importance      = 'impurity', 
  probability = TRUE
)



# Predicting RF
# ***********************

# predict values for test data
pred_rf <- predict(optimal_ranger, data = testData)
RF_Pred_Test = pred_rf$predictions
RF_Pred_Test

score_rf <- predict(optimal_ranger_prob, data = testData)
RF_Score_Test <- score_rf$predictions
RF_Score_Test

# Results of best model
mean(RF_Pred_Test == testData$annahme) # Accuracy






#***************
#5. Prediction for new initiatives!!! (27.11.2021)------
#***************

Dcorona <- c(44, 0, 169, -13, 1, 1, 1, 15.1, 16.8, -25.6, 2.1, 13.2, 7.8, 13.8)

Djustiz <- c(0, -44, 1, -191, 0, 0, 0, -15.1, -16.8, -25.6, -2.1, -13.2, -7.8, -13.8  )

Dpflege <- c(14, -30, 74, -116, 0, 0, 0, -15.1, 16.8, -25.6, 2.1, 13.2, 7.8, 0)


Dnew <- as_tibble(rbind(Dcorona, Djustiz, Dpflege))

colnames(Dnew) <- features 

##standardization:

Dbasic_raw <- Dbasic_raw %>%
  select(-datum, -annahme)

for (i in features_standardize){
  Dnew[[i]] = (Dnew[[i]] - mean(Dbasic_raw[[i]])) / sd(Dbasic_raw[[i]]) #use mean and sd of Dbasic_raw set (just 3 values otherwise), not as accurate as a dataset with dnew but close enough
}


###Stochastic gradient descent:

##Find out scores for Prediction:

#Create an empty list:

new_sgd <- rep(NA, nrow(Dnew))

#Fill with starting value (first weight)

for (i in 1:nrow(Dnew)) {
  new_sgd[i] <- as.numeric(wFinal[1])
}

#apply weights to features for every row

for (i in 1:length(features)) {
  for(j in 1:nrow(Dnew)) {
    new_sgd[j] = new_sgd[j] + wFinal[i+1] * Dnew[j, i]
  }
}


new_sgd <- tibble(as.numeric(new_sgd))

colnames(new_sgd) <- "score"
rownames(new_sgd) <- c("Covid-Gesetz","Justizinitiative","Pflegeinitiative")


new_sgd$prediction <- ifelse(new_sgd$score >= 0.5, 1, 0)




###Neural Network:


NN <- function(Dnew, w1, w2){
  
  X = as.matrix(Dnew[, 1:nX])   # This has dimension nCases x nX
  
  S = X %*% w1                # w1 has dimension nCases x nZ
  
  Z = sigmoidFun(S)           # Same dimensions as S
  
  
  T = Z %*% w2                # w2 has dimension nZ x 1 (for single output node)
  
  prob = sigmoidFun(T)        # Predicted probabilities for output layer
  
  
  out = list(prob = prob)
  
  return(out)
  
}


NNscore_new <- NN(Dnew,w1,w2)

NNscore_new <- as_tibble(NNscore_new)
NNprediction_new <- ifelse(NNscore_new >= c, 1, 0)

colnames(NNprediction_new) <- "PredictionNN_new"
colnames(NNscore_new) <- "ScoreNN_new"



###Boosted Trees

#Apply on new data 

Dnew_boost <- Dnew #new data 
features_test <- vtreat::prepare(treatplan, Dnew_boost, varRestriction = new_vars) %>% as.matrix()
xgbscore_new <- predict(xgb1, features_test)

xgbpred_new <- ifelse (xgbscore_new >= 0.5,1,0)




###Logistic Regression

score_lr_new = predict(modeldumb_final, newdata = Dnew, type = "response")

prediction_lr_new = ifelse(score_lr_new >= c, 1, 0)




###Random Forest

RF_Pred_Dnew <- predict(optimal_ranger, data = Dnew)
RF_Pred_Dnew <- RF_Pred_Dnew[["predictions"]]
RF_Pred_Dnew
RF_Score_Dnew <- predict(optimal_ranger_prob, data = Dnew)
RF_Score_Dnew <- RF_Score_Dnew[["predictions"]]
RF_Score_Dnew




#**************
#5. Majority Vote------
#***************

###For testData-----


#Score:

mv_score_test <- tibble(score_lr_test, RF_Score_Test[, 2], xgbscore)

mv_score_test <- cbind(mv_score_test, NNscore, test_sgd$score)

mv_score_test <- rename(mv_score_test, lrscore = "score_lr_test", rfscore = "RF_Score_Test[, 2]",
                        nnscore = "ScoreNN", sgdscore = "test_sgd$score")

mv_score_test <- mv_score_test %>%
  mutate(meanscore = rowMeans(mv_score_test)) %>%
  mutate(prediction = ifelse(meanscore >= c, 1, 0))

mv_score_test <- cbind(mv_score_test, testData$annahme)
mv_score_test <- rename(mv_score_test, annahme = "testData$annahme")

mean(mv_score_test$prediction == mv_score_test$annahme)


#Prediction:


mv_prediction_test <- tibble(prediction_lr_test, RF_Pred_Test, xgbpred)

mv_prediction_test <- cbind(mv_prediction_test, NNprediction, test_sgd$prediction)

mv_prediction_test <- rename(mv_prediction_test, lrpred = "prediction_lr_test", rfpred = "RF_Pred_Test",
                        nnpred = "PredictionNN", sgdpred = "test_sgd$prediction")

mv_prediction_test$rfpred <- as.numeric(paste(mv_prediction_test$rfpred))

mv_prediction_test <- mv_prediction_test %>%
  mutate(meanpred = rowMeans(mv_prediction_test)) %>%
  mutate(prediction = ifelse(meanpred >= c, 1, 0))

mv_prediction_test <- cbind(mv_prediction_test, testData$annahme)
mv_prediction_test <- rename(mv_prediction_test, annahme = "testData$annahme")

mean(mv_prediction_test$prediction == mv_prediction_test$annahme)

#How often are all models in aggreement 

mean(mv_prediction_test$meanpred == 0) + mean(mv_prediction_test$meanpred == 1)

#Does not get better!


#**************
###For Dnew-----
#**************

#Score:

mv_score_new <- tibble(score_lr_new, RF_Score_Dnew[, 2], xgbscore_new)

mv_score_new <- cbind(mv_score_new, NNscore_new, new_sgd$score)

mv_score_new <- rename(mv_score_new, lrscore = "score_lr_new", rfscore = "RF_Score_Dnew[, 2]",
                        nnscore = "ScoreNN_new", sgdscore = "new_sgd$score", xgbscore = "xgbscore_new")

mv_score_new <- mv_score_new %>%
  mutate(meanscore = rowMeans(mv_score_new)) %>%
  mutate(prediction = ifelse(meanscore >= c, 1, 0))


#Prediction:


mv_prediction_new <- tibble(prediction_lr_new, RF_Pred_Dnew, xgbpred_new)

mv_prediction_new <- cbind(mv_prediction_new, NNprediction_new, new_sgd$prediction)

mv_prediction_new <- rename(mv_prediction_new, lrpred = "prediction_lr_new", rfpred = "RF_Pred_Dnew",
                            xgbpred = "xgbpred_new", nnpred = "PredictionNN_new", sgdpred = "new_sgd$prediction")

mv_prediction_new$rfpred <- as.numeric(paste(mv_prediction_new$rfpred))

mv_prediction_new <- mv_prediction_new %>%
  mutate(meanpred = rowMeans(mv_prediction_new)) %>%
  mutate(prediction = ifelse(meanpred >= c, 1, 0))
